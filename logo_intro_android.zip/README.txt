Kurulum:
1) java/com/example/logointro/*.kt  -> app/src/main/java/<paket>/  (package satirlarini kendi paketine gore duzelt)
2) res/layout/activity_splash.xml   -> app/src/main/res/layout/
3) AndroidManifest.xml icine ekle:
   <activity android:name=".SplashActivity" android:exported="true" android:theme="@style/Theme.AppCompat.Light.NoActionBar">
       <intent-filter>
           <action android:name="android.intent.action.MAIN"/>
           <category android:name="android.intent.category.LAUNCHER"/>
       </intent-filter>
   </activity>
   (MainActivity'deki LAUNCHER intent-filter'i kaldir.)
Sure: LogoIntroView.durationMs (varsayilan 3200 ms).
